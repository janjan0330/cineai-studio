VIDEO GENERATOR — MOBILE-FIRST WEBSITE

Open index.html in a browser. No npm install is required.

To publish: upload index.html to a GitHub repository and import that repository into Vercel. Choose the static/Other framework preset if prompted; no build command is needed.

Important: the interface supports prompt entry, settings, character count, and example prompts. Real AI video generation is not simulated. It requires a secure server-side video API integration. Never put API keys in browser code or a public GitHub repository. A 60-second video may need multiple shorter generated clips and stitching; provider usage may be paid.
